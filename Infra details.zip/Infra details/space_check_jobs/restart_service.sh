#!/bin/bash

# change to source dir
cd '/data/services/gamma'

# activate venv
source 'gammavenv/bin/activate'

# restart application
nohup python3.5 'cloudy_vision_rest.py' &