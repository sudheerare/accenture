#!/bin/bash
# don't cron - use it when required - trigger manually
# removing dangling images
echo "Removing dangling images"
docker rmi $(docker images --filter dangling=true -q 2>/dev/null) 2>/dev/null
echo "Done"

# removing dangling volumes
echo "Removing dangling volumes"
docker volume rm $(docker volume ls --filter dangling=true -q 2>/dev/null) 2>/dev/null
echo "Done"

# removing unused container
# enable at own risk - will clear all stopped containers
# echo "Removing unused containers"
# docker container prune -f

# removing unused container data
# enable at own risk - will clear all stopped containers, images and volumes
# echo "Removing unused container data"
# docker system prune -f
