#!/bin/bash
DEST_FOLDER="/data/services/gamma/history_samples"
INPUT_FOLDER="/data/services/gamma/input_images"
OUTPUT_FOLDER="/data/services/gamma/output"
SAMPLE_FOLDER="/data/services/gamma/demo_input_images"

# removing existing backup
if [[ -d $DEST_FOLDER ]]
        then echo "Removing existing backup" && rm -rf $DEST_FOLDER &> /dev/null
fi

# creating new backup folder
# mkdir $DEST_FOLDER

# backing up current samples
if [[ -d $INPUT_FOLDER ]]
        then mv $INPUT_FOLDER $DEST_FOLDER &> /dev/null
fi

# replacing samples
if [[ -d $SAMPLE_FOLDER ]]
        then cp -r $SAMPLE_FOLDER $INPUT_FOLDER

# removing processed samples
if [[ -d $OUTPUT_FOLDER ]]
        then echo "Removing processed samples" && rm -rf $OUTPUT_FOLDER &> /dev/null
fi

# activate venv
source "/data/services/gamma/gammavenv/bin/activate"

# restart application
python3.5 cloudy_vision.py

# done
echo "Done Resetting samples"