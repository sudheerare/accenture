#!/bin/bash

## storage - /tmp
rm -r /tmp/*.zip
# add whatever is not needed other than UI dist

## memory
sync; echo 2 > /proc/sys/vm/drop_caches