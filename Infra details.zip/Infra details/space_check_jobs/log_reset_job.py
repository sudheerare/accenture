import argparse
import glob
from os import remove
from os.path import basename, exists, getsize
from subprocess import call


def get_file_size(file_path: str = None):
    """

    :param file_path:
    :return:
    """
    size = getsize(file_path)
    # return int(round(size / (1024 * 1024), 3))
    return size


def log_size_check(file_path: str = None, threshold: int = 50):
    """

    :param threshold:
    :param file_path:
    :return:
    """
    log_size = get_file_size(file_path)
    if log_size > threshold:
        return True
    else:
        return False


def restart_service(restart_script_path: str = None):
    """

    :param restart_script_path:
    :return:
    """
    response = call(restart_script_path, shell=True)
    print("Restarted Backend Service")
    return


def generic_logs_check(file_path: str = None, restart_script_path: str = None, threshold: int = 50):
    """

    :param file_path:
    :param restart_script_path:
    :param threshold:
    :return:
    """
    if log_size_check(file_path, threshold):
        print('exceeded limits', basename(file_path))
        if exists(file_path):
            print('Removing redundant log file -i', basename(file_path))
            remove(file_path)
        if not exists(restart_script_path):
            print("File doesn't exist", restart_script_path)
        else:
            restart_service(restart_script_path)
    else:
        print('within limits', basename(file_path))
    return


def logger_logs_check(file_dir_path: str = None):
    """

    :param file_dir_path:
    :return:
    """
    for file in [f for f in glob.glob(file_dir_path + '*log.*[0-9]')]:
        if exists(file):
            print('Removing redundant log file - ', basename(file))
            remove(file)
    return


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='LOG RESET.')
    parser.add_argument('--nohup_file_path', type=str, help='Use this output log file')
    parser.add_argument('--log_dir_path', type=str, help='Use this log directory path')
    parser.add_argument('--restart_script_path', type=str, help='Use this restart script')
    parser.add_argument('--threshold', type=int, help='Use this as log file size threshold (in MB)')

    args = parser.parse_args()
    # check if logs are over threshold
    # nohup
    if args.nohup_file_path and args.restart_script_path and args.threshold:
        if not exists(args.nohup_file_path):
            print("File doesn't exist", args.nohup_file_path)
        else:
            generic_logs_check(file_path=args.nohup_file_path, restart_script_path=args.restart_script_path,
                               threshold=args.threshold)
    # logger logs
    # info
    if args.log_dir_path:
        logger_logs_check(file_dir_path=args.log_dir_path)
    # add methods for other log clearance if required
