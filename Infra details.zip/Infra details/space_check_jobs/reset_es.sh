#!/bin/bash

## es reset

# remove existing backup index
echo "removing existing backup index if any"
curl -X DELETE "localhost:9200/abc_back" &> /dev/null

# backup existing live index
echo "Backup existing live index"
curl -X POST "localhost:9200/_reindex?pretty" -H 'Content-Type: application/json' -d'{  "source": {    "index": "abc"  },  "dest": {    "index": "abc_back"  }}'

# remove live index
echo "Removing live index"
curl -X DELETE "localhost:9200/abc" &> /dev/null

# restore sample index to live
echo "Restoring sample index to live"
curl -X POST "localhost:9200/_reindex?pretty" -H 'Content-Type: application/json' -d'{  "source": {    "index": "abc_sample"  },  "dest": {    "index": "abc"  }}'
