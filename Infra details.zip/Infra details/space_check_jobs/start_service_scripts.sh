vsm-gpu-test -- No idea
PAIR-code - Anandhi -- no idea



current setup can manage the load if 10 people used the APPS 




#! /bin/bash
kill -9 $(lsof -t -i:9042)
cd /data/services/forty2api/
source ./42api/bin/activate
# virtualenv is now active.
nohup python -u rest.py 2>&1 &
sleep 2
echo "Forty2 Restarted"



#! /bin/bash
kill -9 $(lsof -t -i:8086) 2>&1 &
cd /data/services/simon_live/
source ./venv/bin/activate
# virtualenv is now active.
cd  simon-image
rm -rf nohup.out
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "Simoniqr started"


#! /bin/bash
cd /data/services/arthur/editor/server/
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "Arthur started"

#! /bin/bash
cd /root/anaconda3/envs/
conda activate deepsearchenv python3.6
#Activated conda env
cd /data/services/deepsearch/
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "Deepsearch service started"
conda deactivate
echo "conda env deactivated"

#! /bin/bash
cd /data/services/dlite/
source ./dlitevenv/bin/activate
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "dliteplus started"

################################################################################
#! /bin/bash
cd /data/services/session_maintenance/
source ./venv/bin/activate
nohup python3 -u session_token_ip_based_encrypted.py 2>&1 &
sleep 2
echo "Session maintainence service started"

#######################################################################################



#!/bin/bash
cd /data/services/smartads/
source ./venv/bin/activate
nohup python3 -u zRest.py 2>&1 &
sleep 2
echo "smartads(zframes) service started"
####################################################################################

#!/bin/bash
cd /data/services/gamma/
source ./gammavenv/bin/activate
nohup python3 -u cloudy_vision_rest.py 2>&1 &
sleep 2
echo "Gamma service started"



#!/bin/bash
cd /data/services/Saransh
source ./Saranshvenv/bin/activate
nohup python3 -u app.py 2>&1 &
sleep 2
echo "saransh service started
deactivate
echo "first env deleted."
echo "..."
sleep 2
cd /data/services/Saransh/Simon/
source ./env1/bin/activate
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "saransh(text qualuity) service started"

deactivate
echo "second env deactivated."
echo "..."
sleep 2
cd /data/services/Saransh/mantu
source ./env/bin/activate
cd summarize
nohup python3 -u rest.py 2>&1 &
sleep 2
echo "saransh(pointer summary) service started"














9897  9090
9899






