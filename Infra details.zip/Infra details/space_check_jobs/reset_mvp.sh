#!/bin/bash

# gamma

# initiate log reset job
python3.5 "/data/services/gamma/log_reset_job.py" --nohup_file_path "/data/services/gamma/nohup.out" --restart_script_path "/data/services/gamma/reset_job/restart_service.sh" --threshold 50

# initiate sample reset job
bash "/data/services/gamma/reset_job/reset_samples.sh"