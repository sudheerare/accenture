import requests
import os
import sys
import urllib3
resp = requests.get('https://techbare.cognizant.com/buzz')
if resp.status_code != 200:
    # This means something went wrong.
    raise ApiError('GET /shelby/ {}'.format(resp.status_code))
for todo_item in resp.json():
    print('{} {}'.format(todo_item['id'], todo_item['summary']))
    
if __name__ == '__main__':
    APP.run(host='0.0.0.0', port=8088, debug=True)
