@APP.route(BASE_ROOT +'/ad_search',methods=['POST'])
def search():
    result={}
    result1={}
    query_labels=request.json['search']['labels']
    query_logo=request.json['search']['logo']
    query_celebrity=request.json['search']['celebrity']
    query_category=request.json['search']['category']
    query_people=request.json['search']['people']
    query_landmark=request.json['search']['landmark']

    for i in query_logo:
       headers = {
            'Content-Type': 'application/json',
              }
       print(i)
       PARAMS={"query":{"match":{"googleVision.responses.logoAnnotations.description":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)
       results=json.loads(response.text)
       if 'hits' in results:
           print("hits logo")
           data = [doc for doc in results['hits']['hits']]
           for doc in data:
              if str(doc['_id']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+6
                 result.update({str(doc['_id']+"."+str(doc['_source']['extension'])):value})

              else:
               result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):6})
    for i in query_category:
       headers = {
            'Content-Type': 'application/json',
              }
       print(i)
       PARAMS={"query":{"match":{"azureVision.categories.name":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)
       print(response)
       print(response.text)
       results=json.loads(response.text)
       if 'hits' in results:
           print("hits category")
           data = [doc for doc in results['hits']['hits']]
           for doc in data:
              if str(doc['_id']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+1
                 result.update({str(doc['_id']+"."+str(doc['_source']['extension'])):value})

              else:
               result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):1})
    for i in query_people:
       headers = {
            'Content-Type': 'application/json',
              }
       print(i)
       PARAMS={"query":{"match":{"azureVision.faces.gender":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)
       results=json.loads(response.text)
 #      data = [doc for doc in results['hits']['hits']]
       if 'hits' in results:
           print("hits people")
           data = [doc for doc in results['hits']['hits']]
           for doc in data:
              if str(doc['_id']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+2
                 result.update({str(doc['_id']+"."+str(doc['_source']['extension'])):value})

              else:
                 result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):2})

    for i in query_celebrity:
       headers = {
            'Content-Type': 'application/json',
              }
       PARAMS={"query":{"match":{"azureVision.categories.detail.celebrities.name":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)

       results=json.loads(response.text)
#       data = [doc for doc in results['hits']['hits']]
       if 'hits' in results:
           print("cele")
           data = [doc for doc in results['hits']['hits']]
           for doc in data:
              if str(doc['_id']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+4
                 result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):value})

              else:
                  result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):4})
    for i in query_labels:
       headers = {
            'Content-Type': 'application/json',
              }
       PARAMS={"query":{"match":{"googleVision.responses.labelAnnotations.description":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)
       results=json.loads(response.text)
       #data = [doc for doc in results['hits']['hits']]
       if 'hits' in results:
           print("labels")
           data = [doc for doc in results['hits']['hits']]
           for doc in data:
              if str(doc['_id'])+"."+str(doc['_source']['extension']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+3
                 result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):value})

              else:
                  result.update({str(doc['_id']+"."+str(doc['_source']['extension'])):3})
    for i in query_landmark:
       headers = {
            'Content-Type': 'application/json',
              }
       PARAMS={"query":{"match":{"googleVision.responses.landmarkAnnotations.locations.description":{"query":i,"fuzziness": 2,
                "prefix_length": 0,
                "operator":  "and",
                "max_expansions": 100}}}}
       query=json.dumps(PARAMS)
       URL="http://10.232.209.182:9200/ad_image_test/json/_search"
       response = requests.get(URL, headers=headers, data=query)
       results=json.loads(response.text)
       if 'hits' in results:
          print("hits landmark")
          data = [doc for doc in results['hits']['hits']]
          for doc in data:
              if str(doc['_id'])+"."+str(doc['_source']['extension']) in result:
                 value=result[str(doc['_id'])+"."+str(doc['_source']['extension'])]+5
                 result.update({str(doc['_id'])+"."+str(doc['_source']['extension']):value})

              else:
                  result.update({str(doc['_id']+"."+str(doc['_source']['extension'])):5})

    sorted_value = OrderedDict(sorted(result.items(),  reverse=True,key=lambda x: x[1]))
    print(sorted_value)
    return jsonify(sorted_value)