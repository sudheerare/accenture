 Param(
[Parameter(Mandatory=$true,HelpMessage="Enter the value for Action. Values can be either stop or start")][String]$Action
)
 
 
 ### Start StageApp Vms ###############
    $AzureSubscriptionId ="<subscription-id>" 
    $RGName = "<rg-name>"                  
    $VmList = "<vm-names>"
     
    # Get the connection "AzureRunAsConnection"
    Connect-AzAccount -Identity

    $AzureVMs = $VMList.Split(",") 
    [System.Collections.ArrayList]$AzureVMsToHandle = $AzureVMs 

    #Start the Vms
    Write-Output "Starting VMs";
	 ForEach ($vm in $AzureVMs)
      {
        if ($Action.ToLower() -eq 'start')
        {
         Start-AzVM -ResourceGroupName $RGName -Name $vm
        }
        elseif ($Action.ToLower() -eq 'stop')
        {
         Stop-AzVM -ResourceGroupName $RGName -Name $vm -Force
        }

      }